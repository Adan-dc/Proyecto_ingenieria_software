package com.juntavecinal.service;

import com.juntavecinal.exception.ResourceNotFoundException;
import com.juntavecinal.model.SubAdmin;
import com.juntavecinal.repository.SubAdminRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SubAdminService {

    private final SubAdminRepository subAdminRepository;

    public SubAdmin crearSubAdmin(SubAdmin subAdmin) {
        subAdmin.setEstado("ACTIVO");
        return subAdminRepository.save(subAdmin);
    }

    public List<SubAdmin> listarSubAdmins() {
        return subAdminRepository.findAll();
    }

    public void eliminarSubAdmin(Long id) {
        SubAdmin subAdmin = subAdminRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Sub-Admin no encontrado con ID: " + id));
        subAdminRepository.delete(subAdmin);
    }

    public SubAdmin cambiarEstado(Long id, String estado) {
        SubAdmin subAdmin = subAdminRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Sub-Admin no encontrado con ID: " + id));
        subAdmin.setEstado(estado);
        return subAdminRepository.save(subAdmin);
    }
}
