﻿const colors = ['#6366f1', '#ec4899', '#10b981', '#f59e0b', '#8b5cf6', '#0ea5e9', '#ef4444', '#14b8a6'];
      let colorIdx = 0;
      function nextColor() { return colors[colorIdx++ % colors.length]; }

      // Navigation
      const titles = {
        dashboard: 'Panel de Control',
        subadmins: 'Gestión de Sub-Administradores',
        vecinos: 'Registro de Vecinos',
        historial: 'Historial Cronológico',
        config: 'Configuración'
      };

      function navigate(page, el) {
        document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
        if (el) el.classList.add('active');
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        const target = document.getElementById('page-' + page);
        if (target) target.classList.add('active');
        document.getElementById('topbar-title').textContent = titles[page] || '';

        if (page === 'historial') {
          cargarHistorial();
        }
      }

      const API_BASE = 'http://localhost:8080';

      // API Fetch Wrapper
      async function apiFetch(url, options) {
        if (url.startsWith('/')) {
          url = API_BASE + url;
        }
        try {
          const res = await fetch(url, options);
          return res;
        } catch (e) {
          console.warn('Backend no disponible o error de red CORS para:', url);
          if (!options || options.method === 'GET') {
            if (url.includes('/api/subadmins')) {
              return { ok: true, json: async () => [{nombre: 'Admin Prueba (Mock)', correo: 'admin@prueba.com', rol: 'Administrador'}] };
            }
            if (url.includes('/api/vecinos')) {
              return { ok: true, json: async () => [{nombre: 'Vecino', apellido: 'Prueba (Mock)', correo: 'vecino@prueba.com', direccion: 'Casa X', usuario: {rol: 'Vecino'}}] };
            }
          }
          throw e;
        }
      }

      // Toast
      let toastTimer;
      function showToast(msg, icon = '✓') {
        const t = document.getElementById('toast');
        const ti = t.querySelector('.toast-icon');
        document.getElementById('toast-msg').textContent = msg;
        ti.textContent = icon;
        clearTimeout(toastTimer);
        t.classList.add('show');
        toastTimer = setTimeout(() => t.classList.remove('show'), 2800);
      }

      // Modal
      function openNewUserModal() { document.getElementById('modal-overlay').classList.add('open'); }
      function closeModal() { document.getElementById('modal-overlay').classList.remove('open'); }
      document.getElementById('modal-overlay').addEventListener('click', function (e) { if (e.target === this) closeModal(); });

      function setModalTab(el, tab) {
        document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
        el.classList.add('active');
        if (tab === 'subadmin') {
          document.getElementById('m-casa-group').style.display = 'none';
          document.getElementById('m-roles-group').style.display = 'flex';
          document.getElementById('m-roles-group').style.flexDirection = 'column';
          document.getElementById('btn-modal-crear').textContent = 'Crear Sub-Admin';
        } else {
          document.getElementById('m-casa-group').style.display = 'flex';
          document.getElementById('m-roles-group').style.display = 'none';
          document.getElementById('btn-modal-crear').textContent = 'crear vecino ';
        }
      }

      async function crearDesdeModal() {
        const nombre = document.getElementById('m-nombre').value.trim();
        const rut = document.getElementById('m-rut').value.trim();
        const email = document.getElementById('m-email').value.trim();
        const casa = document.getElementById('m-casa').value.trim();
        const isSubadmin = document.getElementById('m-roles-group').style.display !== 'none';

        if (isSubadmin) {
          const rolesChecked = Array.from(document.querySelectorAll('input[name="m-roles"]:checked')).map(cb => cb.value);
          if (!nombre || !email || rolesChecked.length === 0) { showToast('Completa el nombre, correo y selecciona roles', '⚠️'); return; }
          try {
            const res = await apiFetch('/api/subadmins/crear', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ nombre, correo: email, rol: rolesChecked.join(', ') })
            });
            if (res.ok) {
              closeModal();
              ['m-nombre', 'm-rut', 'm-email', 'm-casa'].forEach(id => document.getElementById(id).value = '');
              document.querySelectorAll('input[name="m-roles"]').forEach(cb => cb.checked = false);
              showToast(`Sub-Admin "${nombre}" creado correctamente`, '✅');
            } else {
              showToast('Error al crear el Sub-Admin', '❌');
            }
          } catch (e) {
            showToast('Error de conexión con el backend', '❌');
          }
        } else {
          if (!nombre || !rut || !casa) { showToast('Los campos con * son obligatorios', '⚠️'); return; }
          const partes = nombre.split(' ');
          const primerNombre = partes[0];
          const apellido = partes.slice(1).join(' ') || 'Sin Apellido';
          try {
            const res = await apiFetch('/api/vecinos/registrar', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ rut: rut, nombre: primerNombre, apellido: apellido, correo: email, telefono: '', direccion: casa, usuario: { rol: 'Vecino', activo: true } })
            });
            if (res.ok) {
              closeModal();
              ['m-nombre', 'm-rut', 'm-email', 'm-casa'].forEach(id => document.getElementById(id).value = '');
              showToast(`Vecino "${nombre}" registrado en la BD`, '✅');
            } else {
              showToast('Error al crear el usuario', '❌');
            }
          } catch (e) {
            showToast('Error de conexión con el backend', '❌');
          }
        }
      }

      // Sub-admins
      async function crearSubAdmin() {
        const nombre = document.getElementById('sa-nombre').value.trim();
        const rut = document.getElementById('sa-rut').value.trim();
        const correo = document.getElementById('sa-email').value.trim();
        const rolesChecked = Array.from(document.querySelectorAll('#sa-roles input:checked')).map(cb => cb.value);
        const rol = rolesChecked.join(', ');

        if (!nombre || !rut || !correo || rolesChecked.length === 0) { showToast('Completa todos los campos y selecciona al menos un rol', '⚠️'); return; }

        try {
          const response = await apiFetch('/api/subadmins/crear', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nombre, rut, correo, rol: rolesChecked.join(', ') })
          });

          if (response.ok) {
            const ini = nombre.split(' ').map(w => w[0]).join('').substring(0, 2).toUpperCase();
            const color = nextColor();
            const mainRole = rolesChecked[0];
            const rolBadge = { 'Sub-Admin': 'badge-purple', 'Administrador': 'badge-green', 'Vecino': 'badge-blue' }[mainRole] || 'badge-gray';
            const tr = document.createElement('tr');
            tr.innerHTML = `<td><div class="user-row"><div class="avatar avatar-sm" style="background:${color}">${ini}</div><div><div class="user-name">${nombre}</div><div class="user-email">${correo}</div></div></div></td><td><span class="badge ${rolBadge}">${rol}</span></td><td style="font-size:12.5px;color:var(--text-secondary);">Ahora mismo</td><td><button class="btn btn-sm btn-danger" onclick="eliminarSubAdmin(this)">Eliminar</button></td>`;
            document.getElementById('sa-table').prepend(tr);
            document.getElementById('sa-nombre').value = '';
            document.getElementById('sa-rut').value = '';
            document.getElementById('sa-email').value = '';
            document.querySelectorAll('#sa-roles input').forEach(cb => cb.checked = false);
            showToast(`Sub-Admin "${nombre}" creado en la BD`, '✅');
          } else {
            showToast('Error al crear el Sub-Admin (tal vez el correo ya existe)', '❌');
          }
        } catch (error) {
          console.error("Error:", error);
          showToast('Error de conexión con el backend', '❌');
        }
      }

      function eliminarSubAdmin(btn) {
        const row = btn.closest('tr');
        const nombre = row.querySelector('.user-name').textContent;
        row.style.transition = 'opacity .3s';
        row.style.opacity = '0';
        setTimeout(() => { row.remove(); showToast(`"${nombre}" eliminado`, '🗑️'); }, 300);
      }

      // Vecinos
      async function registrarVecino() {
        const nombreCompleto = document.getElementById('v-nombre').value.trim();
        const rut = document.getElementById('v-rut').value.trim();
        const tel = document.getElementById('v-tel').value.trim();
        const casa = document.getElementById('v-casa').value.trim();
        if (!nombreCompleto || !rut || !casa) { showToast('Los campos marcados con * son obligatorios', '⚠️'); return; }
        const partes = nombreCompleto.split(' ');
        const nombre = partes[0];
        const apellido = partes.slice(1).join(' ') || 'Sin Apellido';
        const btn = document.querySelector('#page-vecinos .btn-primary');
        const originalHTML = btn.innerHTML;
        btn.textContent = 'Registrando...';
        btn.disabled = true;
        try {
          const res = await apiFetch('/api/vecinos/registrar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ rut: rut, nombre: nombre, apellido: apellido, correo: 'sin-correo@vecino.com', telefono: tel, direccion: casa, usuario: { rol: 'Vecino', activo: true } })
          });
          if (res.ok) {
            limpiarFormVecino();
            showToast(`Vecino "${nombreCompleto}" guardado en la base de datos`, '✅');
          } else {
            showToast('Error al guardar en base de datos', '❌');
          }
        } catch (e) {
          showToast('Error de conexión con el backend', '❌');
        } finally {
          btn.innerHTML = originalHTML;
          btn.disabled = false;
        }
      }

      function limpiarFormVecino() {
        ['v-nombre', 'v-rut', 'v-tel', 'v-casa', 'v-contacto', 'v-tel-emerg'].forEach(id => {
          const el = document.getElementById(id);
          if (el) el.value = '';
        });
      }

      // Historial
      async function cargarHistorial() {
        try {
          const tbody = document.getElementById('historial-table');
          tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;">Cargando usuarios...</td></tr>';

          const [resSubadmins, resVecinos] = await Promise.all([
            apiFetch('/api/subadmins'),
            apiFetch('/api/vecinos')
          ]);

          let html = '';

          if (resSubadmins.ok) {
            const subadmins = await resSubadmins.json();
            subadmins.forEach(sa => {
              const ini = sa.nombre.split(' ').map(w => w[0]).join('').substring(0, 2).toUpperCase();
              const color = nextColor();
              const rol = sa.rol || 'Sub-Admin';
              const mainRole = rol.split(',')[0].trim();
              const rolBadge = { 'Sub-Admin': 'badge-purple', 'Administrador': 'badge-green', 'Vecino': 'badge-blue' }[mainRole] || 'badge-gray';
              const estado = sa.estado || 'ACTIVO';
              const bgEstado = estado === 'ACTIVO' ? '#d1fae5' : (estado === 'BLOQUEADO' ? '#fee2e2' : '#fef3c7');
              const colEstado = estado === 'ACTIVO' ? '#065f46' : (estado === 'BLOQUEADO' ? '#991b1b' : '#92400e');
              html += `<tr data-id="${sa.id}" data-type="subadmin">
            <td><div class="user-row"><div class="avatar avatar-sm" style="background:${color}">${ini}</div><div><div class="user-name">${sa.nombre}</div><div class="user-email">${sa.correo}</div></div></div></td>
            <td><span class="badge ${rolBadge}"><span class="dot"></span>${rol}</span></td>
            <td style="font-size:12.5px;color:var(--text-secondary);">N/A</td>
            <td><span style="font-size:11px;font-weight:600;padding:4px 8px;border-radius:12px;background:${bgEstado};color:${colEstado};" class="estado-badge">${estado}</span></td>
            <td><button class="btn btn-sm btn-secondary" onclick="abrirAcciones(this)">Ver</button></td>
          </tr>`;
            });
          }

          if (resVecinos.ok) {
            const vecinos = await resVecinos.json();
            vecinos.forEach(v => {
              const ini = v.nombre.substring(0, 2).toUpperCase();
              const color = nextColor();
              const rol = v.usuario ? v.usuario.rol : 'Vecino';
              const rolBadge = { 'Sub-Admin': 'badge-purple', 'Administrador': 'badge-green', 'Vecino': 'badge-blue' }[rol] || 'badge-blue';
              const estado = (v.usuario && v.usuario.estado) ? v.usuario.estado : 'ACTIVO';
              const bgEstado = estado === 'ACTIVO' ? '#d1fae5' : (estado === 'BLOQUEADO' ? '#fee2e2' : '#fef3c7');
              const colEstado = estado === 'ACTIVO' ? '#065f46' : (estado === 'BLOQUEADO' ? '#991b1b' : '#92400e');
              html += `<tr data-id="${v.id}" data-type="vecino">
            <td><div class="user-row"><div class="avatar avatar-sm" style="background:${color}">${ini}</div><div><div class="user-name">${v.nombre} ${v.apellido}</div><div class="user-email">${v.correo}</div></div></div></td>
            <td><span class="badge ${rolBadge}"><span class="dot"></span>${rol}</span></td>
            <td style="font-size:12.5px;color:var(--text-secondary);">${v.direccion}</td>
            <td><span style="font-size:11px;font-weight:600;padding:4px 8px;border-radius:12px;background:${bgEstado};color:${colEstado};" class="estado-badge">${estado}</span></td>
            <td><button class="btn btn-sm btn-secondary" onclick="abrirAcciones(this)">Ver</button></td>
          </tr>`;
            });
          }

          tbody.innerHTML = html || '<tr><td colspan="5" style="text-align:center;">No hay usuarios registrados</td></tr>';
        } catch (e) {
          console.error(e);
          document.getElementById('historial-table').innerHTML = '<tr><td colspan="5" style="text-align:center;color:red;">Error al cargar historial</td></tr>';
        }
      }



      // Exportar a CSV
      function exportTableToCSV(tbodyId, filename) {
        const tbody = document.getElementById(tbodyId);
        if (!tbody) return;
        
        const table = tbody.closest('table');
        if (!table) return;

        let csv = [];
        const rows = table.querySelectorAll('tr');
        
        for (let i = 0; i < rows.length; i++) {
          let row = [], cols = rows[i].querySelectorAll('td, th');
          
          for (let j = 0; j < cols.length; j++) {
            // Limpiar el texto: quitar saltos de línea y el contenido del botón "Acciones"
            let text = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, " ").trim();
            if (text === 'Acción' || text === 'Acciones' || text.includes('Editar')) continue;
            // Escapar comillas dobles y envolver en comillas
            row.push('"' + text.replace(/"/g, '""') + '"');
          }
          
          if(row.length > 0 && row.join('') !== '""') {
             csv.push(row.join(','));
          }
        }

        const csvFile = new Blob(["\uFEFF" + csv.join('\n')], {type: 'text/csv;charset=utf-8;'});
        const downloadLink = document.createElement('a');
        downloadLink.download = filename;
        downloadLink.href = window.URL.createObjectURL(csvFile);
        downloadLink.style.display = 'none';
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
        showToast('Archivo descargado', '📥');
      }

      // Profile Modal
      function showProfile(nombre, email, rut, casa) {
        document.getElementById('p-nombre').textContent = nombre;
        document.getElementById('p-email').textContent = email;
        document.getElementById('p-rut').textContent = rut;
        document.getElementById('p-casa').textContent = casa;
        document.getElementById('profile-modal-overlay').classList.add('open');
      }
      function closeProfileModal() {
        document.getElementById('profile-modal-overlay').classList.remove('open');
      }
      document.getElementById('profile-modal-overlay').addEventListener('click', function (e) { if (e.target === this) closeProfileModal(); });
      // Acciones Modal
      let accCurrentRow = null;
      let accCurrentId = null;
      let accCurrentType = null;
      function abrirAcciones(btn) {
        const row = btn.closest('tr');
        accCurrentRow = row;
        accCurrentId = row.getAttribute('data-id');
        accCurrentType = row.getAttribute('data-type');
        const nombre = row.querySelector('.user-name').textContent;
        const iniciales = row.querySelector('.avatar').textContent;
        const color = row.querySelector('.avatar').style.background;
        const rol = row.querySelector('.badge').textContent;

        document.getElementById('ac-nombre').textContent = nombre;
        document.getElementById('ac-avatar').textContent = iniciales;
        document.getElementById('ac-avatar').style.background = color;
        document.getElementById('ac-avatar').style.color = '#fff';
        document.getElementById('ac-rol').textContent = rol;
        document.getElementById('acciones-modal-overlay').classList.add('open');
      }
      function closeAccionesModal() {
        document.getElementById('acciones-modal-overlay').classList.remove('open');
      }
      document.getElementById('acciones-modal-overlay').addEventListener('click', function (e) { if (e.target === this) closeAccionesModal(); });

      function accActivar() { cambiarEstadoBackend('ACTIVO'); }
      function accBloquear() { cambiarEstadoBackend('BLOQUEADO'); }

      async function cambiarEstadoBackend(nuevoEstado) {
        const nombre = document.getElementById('ac-nombre').textContent;
        if (!accCurrentId || !accCurrentType) {
          showToast('No se puede cambiar estado: falta ID (usuario de prueba)', '⚠️');
          return;
        }
        const endpoint = accCurrentType === 'subadmin' ? `/api/subadmins/${accCurrentId}/estado?estado=${nuevoEstado}` : `/api/vecinos/${accCurrentId}/estado?estado=${nuevoEstado}`;
        try {
          const res = await apiFetch(endpoint, { method: 'PUT' });
          if (res.ok) {
            showToast(`Cuenta de ${nombre} cambiada a ${nuevoEstado}`, '✅');
            if (accCurrentRow) {
               const badge = accCurrentRow.querySelector('.estado-badge');
               if (badge) {
                  badge.textContent = nuevoEstado;
                  badge.style.background = nuevoEstado === 'ACTIVO' ? '#d1fae5' : (nuevoEstado === 'BLOQUEADO' ? '#fee2e2' : '#fef3c7');
                  badge.style.color = nuevoEstado === 'ACTIVO' ? '#065f46' : (nuevoEstado === 'BLOQUEADO' ? '#991b1b' : '#92400e');
               }
            }
            closeAccionesModal();
          } else {
            showToast('Error al cambiar el estado en BD', '❌');
          }
        } catch (e) {
          showToast('Error de conexión con el backend', '❌');
        }
      }
      async function accEliminar() {
        const nombre = document.getElementById('ac-nombre').textContent;
        if (!accCurrentId || !accCurrentType) {
          showToast('No se puede eliminar: falta ID (usuario de prueba)', '⚠️');
          return;
        }
        const endpoint = accCurrentType === 'subadmin' ? `/api/subadmins/${accCurrentId}` : `/api/vecinos/${accCurrentId}`;
        try {
          const res = await apiFetch(endpoint, { method: 'DELETE' });
          if (res.ok) {
            if (accCurrentRow) {
              accCurrentRow.style.transition = 'opacity .3s';
              accCurrentRow.style.opacity = '0';
              setTimeout(() => { 
                accCurrentRow.remove(); 
                showToast(`Cuenta de "${nombre}" eliminada`, '🗑️'); 
              }, 300);
            }
            closeAccionesModal();
          } else {
            showToast('Error al eliminar cuenta en BD', '❌');
          }
        } catch (e) {
          showToast('Error de conexión con el backend', '❌');
        }
      }
    

    // Login logic
    function doLogin() {
      const email = document.getElementById('login-email').value.trim();
      const pass = document.getElementById('login-password').value.trim();

      if (email === 'admin@juntavecinal.com' && pass === 'admin') {
        document.getElementById('login-container').style.display = 'none';
        document.getElementById('app-container').classList.add('active');

        // Check if showToast is available from the main script
        if (typeof showToast === 'function') {
          showToast('Bienvenido, Administrador', '👋');
        }
      } else {
        if (typeof showToast === 'function') {
          showToast('Error al iniciar sesión', '❌');
        } else {
          alert('Error al iniciar sesión');
        }
      }
    }
